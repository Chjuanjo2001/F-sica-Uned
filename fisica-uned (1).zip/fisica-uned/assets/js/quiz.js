/* ==========================================================================
   MOTOR DE PREGUNTAS
   Se usa en los temas (mini-test por estación), en el examen de certificación
   y en la sesión de repaso espaciado.
   Filosofía: fallar no castiga. Una pregunta fallada vuelve pronto; una
   acertada se aleja en el tiempo. El progreso nunca retrocede.
   ========================================================================== */

import * as store from "./store.js";
import { el } from "./ui.js";

export function renderQuiz(contenedor, opciones) {
  const {
    subject, topic, preguntas,
    examen = false,
    xpPorPregunta = 10,
    aprobadoMin = 0.75,
    esRepaso = false,
    onFin = null,
  } = opciones;

  contenedor.innerHTML = "";
  let respondidasSesion = 0;
  let aciertosSesion = 0;

  preguntas.forEach((item, i) => {
    const idItem = item.id || `q${i}`;
    const previa = store.respuestaDe(subject, topic, idItem);
    const yaAcertada = Boolean(previa?.correct) && !esRepaso;

    const bloque = el("div", { class: "quiz-item" });

    const textoPregunta = el("span", { html: item.q });
    const enunciado = el("div", { class: "q" },
      el("span", { class: "idx" }, `P${i + 1}.`),
      textoPregunta
    );
    bloque.appendChild(enunciado);

    const opts = el("div", { class: "opts" });
    const explicacion = el("div", { class: "explain" },
      el("span", { html: item.explica || "" })
    );

    item.opts.forEach((texto, oi) => {
      const boton = el("button", { class: "opt", type: "button", html: texto });

      if (yaAcertada) {
        boton.disabled = true;
        if (oi === item.correcta) boton.classList.add("correct");
      }

      boton.addEventListener("click", async () => {
        opts.querySelectorAll(".opt").forEach((b) => (b.disabled = true));
        const acierto = oi === item.correcta;
        respondidasSesion++;
        if (acierto) aciertosSesion++;

        if (acierto) {
          boton.classList.add("correct");
        } else {
          boton.classList.add("wrong");
          opts.querySelectorAll(".opt")[item.correcta].classList.add("correct");
        }

        const antes = store.xpTotal();
        await store.registrarRespuesta({
          subject, topic, item: idItem, correct: acierto, xp: xpPorPregunta, esRepaso,
        });
        const ganado = store.xpTotal() - antes;

        if (ganado > 0) {
          textoPregunta.appendChild(el("span", { class: "xp-pop" }, `+${ganado} XP`));
        }

        const nota = el("div", { class: "review-note" },
          acierto
            ? "✓ Guardado. Volverá a aparecer más adelante para consolidarlo."
            : "Sin problema: esta pregunta vuelve en un par de días. Así se aprende."
        );
        explicacion.appendChild(nota);
        explicacion.classList.add("show");

        if (onFin && respondidasSesion === preguntas.length) {
          onFin({ aciertos: aciertosSesion, total: preguntas.length });
        }
        if (examen && respondidasSesion === preguntas.length) {
          await cerrarExamen(contenedor, {
            subject, topic, aciertos: aciertosSesion, total: preguntas.length, aprobadoMin,
          });
        }
      });

      opts.appendChild(boton);
    });

    bloque.appendChild(opts);
    bloque.appendChild(explicacion);
    if (yaAcertada) {
      explicacion.classList.add("show");
      explicacion.appendChild(el("div", { class: "review-note" }, "✓ Ya superada. Aparecerá en los repasos."));
    }
    contenedor.appendChild(bloque);
  });
}

async function cerrarExamen(contenedor, { subject, topic, aciertos, total, aprobadoMin }) {
  const aprobado = aciertos / total >= aprobadoMin;
  await store.registrarExamen({ subject, topic, score: aciertos, total, passed: aprobado });

  const panel = el("div", { class: `exam-result ${aprobado ? "ok" : "again"}` },
    el("div", { class: "exam-ring" }, aprobado ? "🏆" : "↻"),
    el("h3", {}, aprobado ? "Certificado" : "Casi"),
    el("p", {},
      aprobado
        ? `${aciertos} de ${total} correctas. Tema dominado — queda registrado en tu historial de exámenes.`
        : `${aciertos} de ${total} correctas. No pasa nada: las que fallaste entran en la cola de repaso y podrás volver a intentarlo cuando quieras.`
    )
  );
  contenedor.appendChild(panel);
  panel.scrollIntoView({ behavior: "smooth", block: "center" });
}

/* Progreso de un tema a partir de sus preguntas declaradas */
export function progresoDeTema(subject, topic, todasLasPreguntas) {
  return store.progresoTema(subject, topic, todasLasPreguntas.length);
}
