/* ==========================================================================
   CONFIGURACIÓN — el único archivo que necesitas tocar
   ==========================================================================

   MODO LOCAL (por defecto)
   Si dejas SUPABASE_URL y SUPABASE_ANON_KEY vacíos, la aplicación funciona
   igualmente: guarda tu progreso en el propio dispositivo (localStorage).
   Perfecto para estudiar tú solo desde ya, sin registrarte en nada.

   MODO NUBE (cuando quieras cuentas de usuario)
   Rellena las dos claves con los datos de tu proyecto de Supabase y la web
   pasará automáticamente a tener registro, login, sincronización entre
   dispositivos y panel de administración. No hay que cambiar nada más.
   Las instrucciones paso a paso están en README.md.
   ========================================================================== */

export const SUPABASE_URL = "";
export const SUPABASE_ANON_KEY = "";

/* Correos que se convierten automáticamente en administradores al registrarse.
   Pon aquí el tuyo antes de crear tu cuenta, por ejemplo:
   export const ADMIN_EMAILS = ["yo@ejemplo.com"];                            */
export const ADMIN_EMAILS = [];

/* Identidad de la aplicación */
export const APP = {
  nombre: "Física UNED",
  nombreLargo: "Plataforma de estudio · Grado en Física · UNED",
  version: "1.0.0",
};

/* ¿Hay configuración de nube disponible? */
export const CLOUD_ENABLED = Boolean(SUPABASE_URL && SUPABASE_ANON_KEY);
