/* ==========================================================================
   PLAN DE ESTUDIOS — Grado en Física (UNED, código 6104)
   Cada asignatura tiene estado: "abierta" | "construccion"
   Para abrir una asignatura nueva: cambia su estado y añade su "ruta".
   ========================================================================== */

export const CURSOS = [
  {
    n: 1,
    nombre: "Primer curso",
    asignaturas: [
      { code: "ff1",  nombre: "Fundamentos de Física I",    sem: 1, ects: 6, tipo: "básica", estado: "construccion" },
      { code: "am1",  nombre: "Análisis Matemático I",      sem: 1, ects: 6, tipo: "básica", estado: "abierta", ruta: "asignatura.html?code=am1" },
      { code: "alg",  nombre: "Álgebra",                    sem: 1, ects: 6, tipo: "básica", estado: "construccion" },
      { code: "qui",  nombre: "Química",                    sem: 1, ects: 6, tipo: "básica", estado: "construccion" },
      { code: "bio",  nombre: "Biología",                   sem: 1, ects: 6, tipo: "básica", estado: "construccion" },
      { code: "ff2",  nombre: "Fundamentos de Física II",   sem: 2, ects: 6, tipo: "básica", estado: "construccion" },
      { code: "am2",  nombre: "Análisis Matemático II",     sem: 2, ects: 6, tipo: "básica", estado: "construccion" },
      { code: "mm1",  nombre: "Métodos Matemáticos I",      sem: 2, ects: 6, tipo: "básica", estado: "construccion" },
      { code: "fc1",  nombre: "Física Computacional I",     sem: 2, ects: 6, tipo: "básica", estado: "construccion" },
      { code: "te1",  nombre: "Técnicas Experimentales I",  sem: 2, ects: 6, tipo: "básica", estado: "construccion" },
    ],
  },
  {
    n: 2,
    nombre: "Segundo curso",
    asignaturas: [
      { code: "ff3",  nombre: "Fundamentos de Física III",         sem: 1, ects: 6, tipo: "obligatoria", estado: "construccion" },
      { code: "mm2",  nombre: "Métodos Matemáticos II",            sem: 1, ects: 6, tipo: "obligatoria", estado: "construccion" },
      { code: "em1",  nombre: "Electromagnetismo I",               sem: 1, ects: 6, tipo: "obligatoria", estado: "construccion" },
      { code: "fc2",  nombre: "Física Computacional II",           sem: 1, ects: 6, tipo: "obligatoria", estado: "construccion" },
      { code: "mec",  nombre: "Mecánica",                          sem: 1, ects: 6, tipo: "obligatoria", estado: "construccion" },
      { code: "mm3",  nombre: "Métodos Matemáticos III",           sem: 2, ects: 6, tipo: "obligatoria", estado: "construccion" },
      { code: "vo",   nombre: "Vibraciones y Ondas",               sem: 2, ects: 6, tipo: "obligatoria", estado: "construccion" },
      { code: "em2",  nombre: "Electromagnetismo II",              sem: 2, ects: 6, tipo: "obligatoria", estado: "construccion" },
      { code: "tce",  nombre: "Teoría de Circuitos y Electrónica", sem: 2, ects: 6, tipo: "obligatoria", estado: "construccion" },
      { code: "te2",  nombre: "Técnicas Experimentales II",        sem: 2, ects: 6, tipo: "obligatoria", estado: "construccion" },
    ],
  },
  {
    n: 3,
    nombre: "Tercer curso",
    asignaturas: [
      { code: "mm4",  nombre: "Métodos Matemáticos IV",      sem: 1, ects: 6, tipo: "obligatoria", estado: "construccion" },
      { code: "td1",  nombre: "Termodinámica I",             sem: 1, ects: 6, tipo: "obligatoria", estado: "construccion" },
      { code: "fq1",  nombre: "Física Cuántica I",           sem: 1, ects: 6, tipo: "obligatoria", estado: "construccion" },
      { code: "op1",  nombre: "Óptica I",                    sem: 1, ects: 6, tipo: "obligatoria", estado: "construccion" },
      { code: "mt",   nombre: "Mecánica Teórica",            sem: 1, ects: 6, tipo: "obligatoria", estado: "construccion" },
      { code: "td2",  nombre: "Termodinámica II",            sem: 2, ects: 6, tipo: "obligatoria", estado: "construccion" },
      { code: "fq2",  nombre: "Física Cuántica II",          sem: 2, ects: 6, tipo: "obligatoria", estado: "construccion" },
      { code: "op2",  nombre: "Óptica II",                   sem: 2, ects: 6, tipo: "obligatoria", estado: "construccion" },
      { code: "edc",  nombre: "Electrodinámica Clásica",     sem: 2, ects: 6, tipo: "obligatoria", estado: "construccion" },
      { code: "te3",  nombre: "Técnicas Experimentales III", sem: 2, ects: 6, tipo: "obligatoria", estado: "construccion" },
    ],
  },
  {
    n: 4,
    nombre: "Cuarto curso",
    asignaturas: [
      { code: "fnp",  nombre: "Física Nuclear y de Partículas", sem: 1, ects: 6,  tipo: "obligatoria", estado: "construccion" },
      { code: "me",   nombre: "Mecánica Estadística",           sem: 1, ects: 6,  tipo: "obligatoria", estado: "construccion" },
      { code: "ffl",  nombre: "Física de Fluidos",              sem: 1, ects: 6,  tipo: "obligatoria", estado: "construccion" },
      { code: "fes",  nombre: "Física del Estado Sólido",       sem: 2, ects: 6,  tipo: "obligatoria", estado: "construccion" },
      { code: "te4",  nombre: "Técnicas Experimentales IV",     sem: 2, ects: 6,  tipo: "obligatoria", estado: "construccion" },
      { code: "mca",  nombre: "Mecánica Cuántica Avanzada",     sem: 1, ects: 5,  tipo: "optativa",    estado: "construccion" },
      { code: "ast",  nombre: "Astrofísica General",            sem: 2, ects: 5,  tipo: "optativa",    estado: "construccion" },
      { code: "rg",   nombre: "Relatividad General",            sem: 2, ects: 5,  tipo: "optativa",    estado: "construccion" },
      { code: "bfi",  nombre: "Biofísica",                      sem: 1, ects: 5,  tipo: "optativa",    estado: "construccion" },
      { code: "tfg",  nombre: "Trabajo Fin de Grado",           sem: 0, ects: 10, tipo: "TFG",         estado: "construccion" },
    ],
  },
];

/* Índice rápido por código */
export const ASIGNATURAS = Object.fromEntries(
  CURSOS.flatMap((c) => c.asignaturas.map((a) => [a.code, { ...a, curso: c.n }]))
);

/* ==========================================================================
   TEMARIOS — por ahora solo Análisis Matemático I está abierta
   estado: "publicado" | "pendiente"
   ========================================================================== */

export const TEMARIOS = {
  am1: {
    nombre: "Análisis Matemático I",
    apodo: "Observatorio de Cálculo I",
    descripcion:
      "Cálculo de una variable mirado siempre desde la física: cinemática, campos, ondas y órbitas.",
    temas: [
      { code: "preliminares", n: 1,  titulo: "Preliminares",                             gancho: "Números, rectas, cónicas, funciones y trigonometría", estado: "publicado", ruta: "temas/am1-01-preliminares.html", preguntas: 21 },
      { code: "limites",      n: 2,  titulo: "Límites y continuidad",                     gancho: "El instante en el cálculo de velocidades",           estado: "pendiente" },
      { code: "derivadas",    n: 3,  titulo: "Diferenciación",                            gancho: "La derivada como razón de cambio física",            estado: "pendiente" },
      { code: "trascendentes",n: 4,  titulo: "Funciones trascendentes",                   gancho: "Crecimiento exponencial, desintegración radiactiva", estado: "pendiente" },
      { code: "aplic-deriv",  n: 5,  titulo: "Aplicaciones de las derivadas",             gancho: "Optimización y razones de cambio relacionadas",      estado: "pendiente" },
      { code: "integracion",  n: 6,  titulo: "Integración",                               gancho: "De la velocidad a la posición",                      estado: "pendiente" },
      { code: "tecnicas-int", n: 7,  titulo: "Técnicas de integración",                   gancho: "El arsenal para resolver integrales reales",         estado: "pendiente" },
      { code: "aplic-int",    n: 8,  titulo: "Aplicaciones de la integración",            gancho: "Trabajo, energía y centros de masa",                 estado: "pendiente" },
      { code: "conicas",      n: 9,  titulo: "Cónicas paramétricas y polares",            gancho: "Órbitas en coordenadas naturales",                   estado: "pendiente" },
      { code: "series",       n: 10, titulo: "Secuencias, series y series de potencias",  gancho: "Aproximaciones de Taylor en física",                 estado: "pendiente" },
      { code: "complejos",    n: 11, titulo: "Apéndice I · Números complejos",            gancho: "Oscilaciones y ondas con fasores",                   estado: "pendiente" },
      { code: "func-complej", n: 12, titulo: "Apéndice II · Funciones complejas",         gancho: "Herramientas para electromagnetismo",                estado: "pendiente" },
      { code: "continuas",    n: 13, titulo: "Apéndice III · Funciones continuas",        gancho: "El rigor detrás de la intuición física",             estado: "pendiente" },
      { code: "riemann",      n: 14, titulo: "Apéndice IV · La integral de Riemann",      gancho: "Qué significa sumar infinitos trocitos",             estado: "pendiente" },
    ],
    recursos: [
      { titulo: "Tablas de fórmulas e integrales", nota: "Chuleta rápida de derivadas e integrales" },
      { titulo: "Soluciones de ejercicios impares", nota: "Para autocorregirte tras cada estación" },
    ],
  },
};

/* Utilidades */
export function temasDe(subjectCode) {
  return TEMARIOS[subjectCode]?.temas ?? [];
}
export function temaPublicado(subjectCode, topicCode) {
  return temasDe(subjectCode).find((t) => t.code === topicCode && t.estado === "publicado");
}
export function totalTemasPublicados() {
  return Object.values(TEMARIOS).reduce(
    (acc, s) => acc + s.temas.filter((t) => t.estado === "publicado").length, 0
  );
}
export function totalAsignaturas() {
  return CURSOS.reduce((acc, c) => acc + c.asignaturas.length, 0);
}
export function asignaturasAbiertas() {
  return CURSOS.flatMap((c) => c.asignaturas).filter((a) => a.estado === "abierta");
}
