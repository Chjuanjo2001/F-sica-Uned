/* ==========================================================================
   REGISTRO DE BANCOS DE PREGUNTAS
   Cada tema publicado registra aquí su módulo. La sesión de repaso lo usa
   para recuperar el enunciado de cualquier pregunta pendiente.
   Para añadir un tema nuevo: crea assets/js/banco/<asignatura>-<tema>.js
   y añade una línea a REGISTRO.
   ========================================================================== */

export const REGISTRO = {
  "am1/preliminares": () => import("./banco/am1-preliminares.js"),
};

const cache = new Map();

export async function cargarBanco(subject, topic) {
  const clave = `${subject}/${topic}`;
  if (cache.has(clave)) return cache.get(clave);
  const cargador = REGISTRO[clave];
  if (!cargador) return null;
  const modulo = await cargador();
  cache.set(clave, modulo);
  return modulo;
}

export async function buscarPregunta(subject, topic, itemId) {
  const banco = await cargarBanco(subject, topic);
  if (!banco) return null;
  return banco.TODAS.find((p) => p.id === itemId) || null;
}

/* Devuelve las preguntas completas correspondientes a una lista de pendientes
   del repaso espaciado, descartando las que ya no existan en el banco. */
export async function hidratarPendientes(pendientes) {
  const resultado = [];
  for (const p of pendientes) {
    const pregunta = await buscarPregunta(p.subject, p.topic, p.item);
    if (pregunta) resultado.push({ ...p, pregunta });
  }
  return resultado;
}

export async function metaDeTema(subject, topic) {
  const banco = await cargarBanco(subject, topic);
  return banco?.META || null;
}
