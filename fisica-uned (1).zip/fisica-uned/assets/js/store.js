/* ==========================================================================
   STORE — sesión, usuarios y progreso
   Funciona en dos modos de forma transparente:
     · MODO LOCAL  → todo se guarda en este dispositivo (localStorage)
     · MODO NUBE   → Supabase (auth + Postgres), con caché local y cola offline
   ========================================================================== */

import { SUPABASE_URL, SUPABASE_ANON_KEY, CLOUD_ENABLED, ADMIN_EMAILS } from "./config.js";

const LS = {
  progress: "fu_progress_v1",
  exams: "fu_exams_v1",
  profile: "fu_local_profile_v1",
  queue: "fu_sync_queue_v1",
};

/* ---------- utilidades de almacenamiento seguro ---------- */
function lsGet(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch (e) {
    return fallback;
  }
}
function lsSet(key, value) {
  try { localStorage.setItem(key, JSON.stringify(value)); } catch (e) { /* modo privado */ }
}

/* ---------- niveles ---------- */
export const NIVELES = [
  { min: 0,   titulo: "Aprendiz de Newton" },
  { min: 60,  titulo: "Técnico de Laboratorio" },
  { min: 150, titulo: "Analista de Trayectorias" },
  { min: 280, titulo: "Maestro de Kepler" },
  { min: 450, titulo: "Físico Certificado" },
  { min: 700, titulo: "Catedrático de Cálculo" },
];
export function nivelDe(xp) {
  let i = 0;
  NIVELES.forEach((n, idx) => { if (xp >= n.min) i = idx; });
  const siguiente = NIVELES[i + 1];
  return {
    nivel: i + 1,
    titulo: NIVELES[i].titulo,
    desde: NIVELES[i].min,
    hasta: siguiente ? siguiente.min : NIVELES[i].min + 300,
    porcentaje: siguiente
      ? Math.min(100, Math.round((100 * (xp - NIVELES[i].min)) / (siguiente.min - NIVELES[i].min)))
      : 100,
  };
}

/* ---------- cliente Supabase (carga perezosa) ---------- */
let _client = null;
async function client() {
  if (!CLOUD_ENABLED) return null;
  if (_client) return _client;
  const { createClient } = await import("https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm");
  _client = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
    auth: { persistSession: true, autoRefreshToken: true },
  });
  return _client;
}

/* ---------- estado en memoria ---------- */
const state = {
  modo: CLOUD_ENABLED ? "nube" : "local",
  listo: false,
  user: null,       // { id, email, nombre, rol }
  answers: {},      // "subject/topic/item" → { correct, xp, at }
  exams: [],        // { subject, topic, score, total, passed, at }
};

export function modo() { return state.modo; }
export function usuario() { return state.user; }
export function esAdmin() { return state.user?.rol === "admin"; }
export function estaListo() { return state.listo; }

const listeners = new Set();
export function onCambio(cb) { listeners.add(cb); return () => listeners.delete(cb); }
function emitir() { listeners.forEach((cb) => { try { cb(state); } catch (e) {} }); }

/* ---------- perfil local ---------- */
function perfilLocal() {
  let p = lsGet(LS.profile, null);
  if (!p) {
    p = { id: "local", email: null, nombre: "Estudiante", rol: "admin" };
    lsSet(LS.profile, p);
  }
  return p;
}
export function renombrarLocal(nombre) {
  const p = perfilLocal();
  p.nombre = nombre;
  lsSet(LS.profile, p);
  if (state.modo === "local") { state.user = p; emitir(); }
}

/* ==========================================================================
   INICIALIZACIÓN
   ========================================================================== */
export async function init() {
  state.answers = lsGet(LS.progress, {});
  state.exams = lsGet(LS.exams, []);

  if (state.modo === "local") {
    state.user = perfilLocal();
    state.listo = true;
    emitir();
    return state;
  }

  try {
    const sb = await client();
    const { data: { session } } = await sb.auth.getSession();
    if (session?.user) {
      await cargarUsuarioNube(sb, session.user);
      await cargarProgresoNube(sb);
      await vaciarCola();
    } else {
      state.user = null;
    }
    sb.auth.onAuthStateChange(async (_evento, sesion) => {
      if (sesion?.user) {
        await cargarUsuarioNube(sb, sesion.user);
        await cargarProgresoNube(sb);
      } else {
        state.user = null;
      }
      emitir();
    });
  } catch (e) {
    console.warn("No se pudo conectar con la nube, se usa el modo local:", e.message);
    state.modo = "local";
    state.user = perfilLocal();
  }

  state.listo = true;
  emitir();
  return state;
}

async function cargarUsuarioNube(sb, authUser) {
  let { data: perfil } = await sb.from("profiles").select("*").eq("id", authUser.id).maybeSingle();

  if (!perfil) {
    const rolInicial = ADMIN_EMAILS.includes(authUser.email) ? "admin" : "student";
    const { data } = await sb.from("profiles").insert({
      id: authUser.id,
      email: authUser.email,
      display_name: authUser.user_metadata?.display_name || authUser.email.split("@")[0],
      role: rolInicial,
    }).select().maybeSingle();
    perfil = data;
  } else {
    sb.from("profiles").update({ last_seen_at: new Date().toISOString() }).eq("id", authUser.id).then(() => {});
  }

  state.user = {
    id: authUser.id,
    email: authUser.email,
    nombre: perfil?.display_name || authUser.email.split("@")[0],
    rol: perfil?.role || "student",
  };
}

async function cargarProgresoNube(sb) {
  const { data: filas } = await sb
    .from("progress")
    .select("subject_code, topic_code, item_id, correct, xp, answered_at, box, due_date, attempts, misses")
    .eq("user_id", state.user.id);
  if (filas) {
    const mapa = {};
    filas.forEach((f) => {
      mapa[`${f.subject_code}/${f.topic_code}/${f.item_id}`] = {
        correct: f.correct, xp: f.xp, at: f.answered_at,
        box: f.box ?? 0, due: f.due_date, intentos: f.attempts ?? 1, fallos: f.misses ?? 0,
      };
    });
    // La nube manda, pero conservamos lo que solo exista en local (pendiente de subir)
    state.answers = { ...state.answers, ...mapa };
    lsSet(LS.progress, state.answers);
  }
  const { data: examenes } = await sb
    .from("exam_results")
    .select("subject_code, topic_code, score, total, passed, taken_at")
    .eq("user_id", state.user.id)
    .order("taken_at", { ascending: false });
  if (examenes) {
    state.exams = examenes.map((e) => ({
      subject: e.subject_code, topic: e.topic_code, score: e.score,
      total: e.total, passed: e.passed, at: e.taken_at,
    }));
    lsSet(LS.exams, state.exams);
  }
}

/* ==========================================================================
   AUTENTICACIÓN
   ========================================================================== */
export async function registrarse(email, password, nombre) {
  const sb = await client();
  if (!sb) throw new Error("La nube no está configurada todavía.");
  const { data, error } = await sb.auth.signUp({
    email, password,
    options: { data: { display_name: nombre } },
  });
  if (error) throw new Error(traducirError(error.message));
  return data;
}

export async function entrar(email, password) {
  const sb = await client();
  if (!sb) throw new Error("La nube no está configurada todavía.");
  const { data, error } = await sb.auth.signInWithPassword({ email, password });
  if (error) throw new Error(traducirError(error.message));
  await cargarUsuarioNube(sb, data.user);
  await cargarProgresoNube(sb);
  await vaciarCola();
  emitir();
  return data;
}

export async function salir() {
  const sb = await client();
  if (sb) await sb.auth.signOut();
  state.user = null;
  emitir();
}

export async function recuperarContrasena(email) {
  const sb = await client();
  if (!sb) throw new Error("La nube no está configurada todavía.");
  const { error } = await sb.auth.resetPasswordForEmail(email, {
    redirectTo: window.location.origin + "/login.html",
  });
  if (error) throw new Error(traducirError(error.message));
}

function traducirError(msg) {
  const m = (msg || "").toLowerCase();
  if (m.includes("invalid login")) return "Correo o contraseña incorrectos.";
  if (m.includes("already registered")) return "Ese correo ya tiene cuenta. Prueba a entrar.";
  if (m.includes("password should be")) return "La contraseña debe tener al menos 6 caracteres.";
  if (m.includes("email not confirmed")) return "Tienes que confirmar el correo antes de entrar.";
  if (m.includes("rate limit")) return "Demasiados intentos seguidos. Espera un minuto.";
  return msg;
}

/* ==========================================================================
   PROGRESO
   ========================================================================== */
export function clave(subject, topic, item) { return `${subject}/${topic}/${item}`; }

export function respuestaDe(subject, topic, item) {
  return state.answers[clave(subject, topic, item)] || null;
}

export function respuestasDeTema(subject, topic) {
  const prefijo = `${subject}/${topic}/`;
  const res = {};
  Object.entries(state.answers).forEach(([k, v]) => {
    if (k.startsWith(prefijo)) res[k.slice(prefijo.length)] = v;
  });
  return res;
}

/* Repaso espaciado (sistema Leitner): días hasta el próximo repaso según caja */
const INTERVALOS = [1, 1, 3, 7, 16, 35];
function proximaFecha(caja) {
  const dias = INTERVALOS[Math.min(caja, INTERVALOS.length - 1)];
  const d = new Date();
  d.setDate(d.getDate() + dias);
  return d.toISOString().slice(0, 10);
}

export async function registrarRespuesta({ subject, topic, item, correct, xp = 0, esRepaso = false }) {
  const k = clave(subject, topic, item);
  const previa = state.answers[k];

  // El XP solo se concede la primera vez que se acierta; los repasos no puntúan de nuevo,
  // pero sí actualizan la caja de repaso espaciado.
  const yaPuntuada = Boolean(previa?.correct);
  const cajaPrevia = previa?.box ?? 0;
  const caja = correct ? Math.min(cajaPrevia + 1, INTERVALOS.length - 1) : Math.max(cajaPrevia - 1, 0);

  const registro = {
    correct,
    xp: yaPuntuada ? (previa.xp || 0) : (correct ? xp : 0),
    at: previa?.at || new Date().toISOString(),
    ultimo: new Date().toISOString(),
    box: caja,
    due: proximaFecha(caja),
    intentos: (previa?.intentos || 0) + 1,
    fallos: (previa?.fallos || 0) + (correct ? 0 : 1),
  };
  // Una pregunta ya superada nunca "se desaprende": el progreso no retrocede.
  if (yaPuntuada) registro.correct = true;

  state.answers[k] = registro;
  lsSet(LS.progress, state.answers);
  emitir();

  if (state.modo === "nube" && state.user) {
    const fila = {
      user_id: state.user.id, subject_code: subject, topic_code: topic,
      item_id: item, correct: registro.correct, xp: registro.xp,
      answered_at: registro.at, box: registro.box, due_date: registro.due,
      attempts: registro.intentos, misses: registro.fallos,
    };
    try {
      const sb = await client();
      const { error } = await sb.from("progress").upsert(fila, {
        onConflict: "user_id,subject_code,topic_code,item_id",
      });
      if (error) encolar("progress", fila);
    } catch (e) {
      encolar("progress", fila);
    }
  }
  return registro;
}

export async function registrarExamen({ subject, topic, score, total, passed }) {
  const registro = { subject, topic, score, total, passed, at: new Date().toISOString() };
  state.exams.unshift(registro);
  lsSet(LS.exams, state.exams);
  emitir();

  if (state.modo === "nube" && state.user) {
    const fila = {
      user_id: state.user.id, subject_code: subject, topic_code: topic,
      score, total, passed, taken_at: registro.at,
    };
    try {
      const sb = await client();
      const { error } = await sb.from("exam_results").insert(fila);
      if (error) encolar("exam_results", fila);
    } catch (e) {
      encolar("exam_results", fila);
    }
  }
  return registro;
}

export function examenes() { return state.exams; }

/* ---------- cola de sincronización offline ---------- */
function encolar(tabla, fila) {
  const cola = lsGet(LS.queue, []);
  cola.push({ tabla, fila });
  lsSet(LS.queue, cola);
}
export async function vaciarCola() {
  if (state.modo !== "nube" || !state.user) return;
  const cola = lsGet(LS.queue, []);
  if (!cola.length) return;
  const sb = await client();
  const restantes = [];
  for (const item of cola) {
    try {
      const fila = { ...item.fila, user_id: state.user.id };
      const { error } = item.tabla === "progress"
        ? await sb.from("progress").upsert(fila, { onConflict: "user_id,subject_code,topic_code,item_id" })
        : await sb.from("exam_results").insert(fila);
      if (error) restantes.push(item);
    } catch (e) { restantes.push(item); }
  }
  lsSet(LS.queue, restantes);
}
window.addEventListener("online", () => { vaciarCola(); });

/* ==========================================================================
   ESTADÍSTICAS DEL USUARIO
   ========================================================================== */
export function xpTotal() {
  return Object.values(state.answers).reduce((a, r) => a + (r.xp || 0), 0);
}
export function aciertos() {
  const vals = Object.values(state.answers);
  return { correctas: vals.filter((v) => v.correct).length, total: vals.length };
}
export function progresoTema(subject, topic, totalPreguntas) {
  const r = respuestasDeTema(subject, topic);
  const correctas = Object.values(r).filter((v) => v.correct).length;
  return {
    correctas,
    total: totalPreguntas,
    porcentaje: totalPreguntas ? Math.round((100 * correctas) / totalPreguntas) : 0,
    completado: totalPreguntas > 0 && correctas >= totalPreguntas,
  };
}
export function temasConActividad() {
  const s = new Set();
  Object.keys(state.answers).forEach((k) => {
    const [subject, topic] = k.split("/");
    s.add(`${subject}/${topic}`);
  });
  return [...s];
}
export function actividadPorDia(dias = 30) {
  const hoy = new Date();
  const mapa = {};
  for (let i = dias - 1; i >= 0; i--) {
    const d = new Date(hoy); d.setDate(hoy.getDate() - i);
    mapa[d.toISOString().slice(0, 10)] = 0;
  }
  Object.values(state.answers).forEach((r) => {
    const dia = (r.at || "").slice(0, 10);
    if (dia in mapa) mapa[dia] += 1;
  });
  return mapa;
}
export function diasActivos() {
  return new Set(Object.values(state.answers).map((r) => (r.at || "").slice(0, 10))).size;
}
export function mejorRacha() {
  const dias = [...new Set(Object.values(state.answers).map((r) => (r.at || "").slice(0, 10)))]
    .filter(Boolean).sort();
  let mejor = 0, actual = 0, previo = null;
  dias.forEach((d) => {
    if (previo) {
      const dif = (new Date(d) - new Date(previo)) / 86400000;
      actual = dif === 1 ? actual + 1 : 1;
    } else actual = 1;
    mejor = Math.max(mejor, actual);
    previo = d;
  });
  return mejor;
}
export function rachaDias() {
  const dias = new Set(Object.values(state.answers).map((r) => (r.at || "").slice(0, 10)));
  let racha = 0;
  const d = new Date();
  // permite que hoy aún no haya actividad sin romper la racha de ayer
  if (!dias.has(d.toISOString().slice(0, 10))) d.setDate(d.getDate() - 1);
  while (dias.has(d.toISOString().slice(0, 10))) { racha++; d.setDate(d.getDate() - 1); }
  return racha;
}

/* ==========================================================================
   REPASO ESPACIADO — qué toca repasar hoy
   Nada caduca ni se pierde: si pasan semanas, la cola simplemente espera.
   ========================================================================== */
export function pendientesDeRepaso(limite = 999) {
  const hoy = new Date().toISOString().slice(0, 10);
  return Object.entries(state.answers)
    .filter(([, v]) => v.due && v.due <= hoy)
    .map(([k, v]) => {
      const [subject, topic, item] = k.split("/");
      return { clave: k, subject, topic, item, ...v };
    })
    .sort((a, b) => (a.box - b.box) || (a.due < b.due ? -1 : 1))
    .slice(0, limite);
}

export function resumenRepaso() {
  const pend = pendientesDeRepaso();
  const total = Object.keys(state.answers).length;
  const dominadas = Object.values(state.answers).filter((v) => (v.box ?? 0) >= 4).length;
  const flojas = Object.values(state.answers).filter((v) => (v.box ?? 0) <= 1 && v.intentos).length;
  return { pendientes: pend.length, total, dominadas, flojas };
}

/* Duraciones de sesión (minutos → nº de preguntas aproximado) */
export const SESIONES = [
  { id: "corta",   min: 5,  preguntas: 5,  etiqueta: "Sesión corta",  nota: "Día flojo: solo repaso" },
  { id: "media",   min: 10, preguntas: 10, etiqueta: "Sesión media",  nota: "Repaso + un bloque nuevo" },
  { id: "completa",min: 25, preguntas: 20, etiqueta: "Sesión completa",nota: "Tema nuevo entero" },
];
export function sesionPreferida() { return lsGet("fu_sesion_pref", "media"); }
export function guardarSesionPreferida(id) { lsSet("fu_sesion_pref", id); }

/* ==========================================================================
   ADMINISTRACIÓN (solo rol admin; en modo local devuelve datos propios)
   ========================================================================== */
export async function adminUsuarios() {
  if (state.modo === "local") {
    const resumen = aciertos();
    return [{
      id: "local", email: "(modo local)", display_name: state.user?.nombre || "Estudiante",
      role: "admin", created_at: null, last_seen_at: new Date().toISOString(),
      xp: xpTotal(), respuestas: resumen.total, correctas: resumen.correctas,
    }];
  }
  const sb = await client();
  const { data: perfiles, error } = await sb
    .from("profiles").select("*").order("created_at", { ascending: false });
  if (error) throw new Error(error.message);

  const { data: progreso } = await sb.from("progress").select("user_id, xp, correct");
  const agregado = {};
  (progreso || []).forEach((p) => {
    const a = (agregado[p.user_id] ||= { xp: 0, respuestas: 0, correctas: 0 });
    a.xp += p.xp || 0; a.respuestas += 1; if (p.correct) a.correctas += 1;
  });

  return (perfiles || []).map((p) => ({
    ...p,
    xp: agregado[p.id]?.xp || 0,
    respuestas: agregado[p.id]?.respuestas || 0,
    correctas: agregado[p.id]?.correctas || 0,
  }));
}

export async function adminCambiarRol(userId, rol) {
  if (state.modo === "local") throw new Error("Disponible solo en modo nube.");
  const sb = await client();
  const { error } = await sb.from("profiles").update({ role: rol }).eq("id", userId);
  if (error) throw new Error(error.message);
}

export async function adminExamenes() {
  if (state.modo === "local") {
    return state.exams.map((e) => ({ ...e, email: "(modo local)" }));
  }
  const sb = await client();
  const { data } = await sb
    .from("exam_results")
    .select("subject_code, topic_code, score, total, passed, taken_at, profiles(email, display_name)")
    .order("taken_at", { ascending: false })
    .limit(100);
  return (data || []).map((e) => ({
    subject: e.subject_code, topic: e.topic_code, score: e.score, total: e.total,
    passed: e.passed, at: e.taken_at,
    email: e.profiles?.email || "—", nombre: e.profiles?.display_name || "—",
  }));
}

export async function adminPreguntasDificiles() {
  if (state.modo === "local") {
    return Object.entries(state.answers)
      .filter(([, v]) => !v.correct)
      .map(([k]) => ({ item: k, fallos: 1, intentos: 1 }));
  }
  const sb = await client();
  const { data } = await sb.from("progress").select("subject_code, topic_code, item_id, correct");
  const mapa = {};
  (data || []).forEach((r) => {
    const k = `${r.subject_code}/${r.topic_code}/${r.item_id}`;
    const m = (mapa[k] ||= { item: k, fallos: 0, intentos: 0 });
    m.intentos += 1; if (!r.correct) m.fallos += 1;
  });
  return Object.values(mapa).filter((m) => m.fallos > 0).sort((a, b) => b.fallos - a.fallos).slice(0, 12);
}
