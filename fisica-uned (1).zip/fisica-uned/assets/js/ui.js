/* ==========================================================================
   UI — cabecera compartida, chip de usuario y utilidades comunes
   ========================================================================== */

import * as store from "./store.js";
import { APP } from "./config.js";

export function el(tag, props = {}, ...hijos) {
  const n = document.createElement(tag);
  Object.entries(props).forEach(([k, v]) => {
    if (k === "class") n.className = v;
    else if (k === "html") n.innerHTML = v;
    else if (k.startsWith("on") && typeof v === "function") n.addEventListener(k.slice(2).toLowerCase(), v);
    else if (v !== null && v !== undefined && v !== false) n.setAttribute(k, v);
  });
  hijos.flat().forEach((h) => {
    if (h === null || h === undefined || h === false) return;
    n.appendChild(typeof h === "string" ? document.createTextNode(h) : h);
  });
  return n;
}

/* Ruta relativa a la raíz según la profundidad de la página actual */
export function raiz() {
  return window.location.pathname.includes("/temas/") ? "../" : "";
}

const NAV = [
  { href: "index.html", texto: "El grado" },
  { href: "asignatura.html?code=am1", texto: "Cálculo I" },
  { href: "repaso.html", texto: "Repaso" },
  { href: "perfil.html", texto: "Mi progreso" },
];

export function montarCabecera(paginaActual = "") {
  const r = raiz();
  const barra = el("header", { class: "appbar" });
  const inner = el("div", { class: "appbar-inner" });

  inner.appendChild(
    el("a", { class: "brand", href: r + "index.html" },
      el("span", { class: "spark" }, "◉"),
      APP.nombre
    )
  );

  const nav = el("nav");
  NAV.forEach((item) => {
    const base = item.href.split("?")[0].replace(".html", "");
    const props = { href: r + item.href };
    if (base === paginaActual) props["aria-current"] = "page";
    nav.appendChild(el("a", props, item.texto));
  });
  inner.appendChild(nav);
  inner.appendChild(el("div", { class: "spacer" }));

  const zonaUsuario = el("div", { id: "zonaUsuario" });
  inner.appendChild(zonaUsuario);
  barra.appendChild(inner);

  document.body.prepend(barra);
  if (store.modo() === "local") {
    barra.after(
      el("div", { class: "localbanner" },
        "Modo local · tu progreso se guarda en este dispositivo. Configura Supabase (README) para tener cuenta y sincronizar entre iPad y Mac."
      )
    );
  }

  const pintar = () => pintarUsuario(zonaUsuario, paginaActual);
  pintar();
  store.onCambio(pintar);
}

function pintarUsuario(zona, paginaActual) {
  zona.innerHTML = "";
  const r = raiz();
  const u = store.usuario();

  if (!u) {
    zona.appendChild(el("a", { class: "btn small primary", href: r + "login.html" }, "Entrar"));
    return;
  }

  const xp = store.xpTotal();
  const nivel = store.nivelDe(xp);
  const inicial = (u.nombre || "?").trim().charAt(0).toUpperCase();

  const chip = el("a", { class: "userchip", href: r + "perfil.html", title: `${u.nombre} · ${nivel.titulo}` },
    el("span", { class: "avatar" }, inicial),
    el("span", { class: "meta" },
      el("span", { class: "n" }, u.nombre),
      el("span", { class: "x" }, `Nv.${nivel.nivel} · ${xp} XP`)
    )
  );
  zona.appendChild(chip);

  if (store.esAdmin() && paginaActual !== "admin") {
    zona.appendChild(el("a", { class: "btn small ghost", href: r + "admin.html", style: "margin-left:8px" }, "Admin"));
  }
}

/* Pie de página común */
export function montarPie() {
  const r = raiz();
  document.body.appendChild(
    el("footer", { class: "appfoot" },
      el("div", {}, `${APP.nombreLargo} · v${APP.version}`),
      el("div", { style: "margin-top:6px" },
        el("a", { href: r + "index.html" }, "El grado"), " · ",
        el("a", { href: r + "repaso.html" }, "Repaso de hoy"), " · ",
        el("a", { href: r + "perfil.html" }, "Mi progreso")
      )
    )
  );
}

/* Anillo de progreso reutilizable */
export function anillo(porcentaje, tamano = 74, etiqueta = null) {
  const radio = tamano / 2 - 6;
  const circ = 2 * Math.PI * radio;
  const offset = circ * (1 - Math.max(0, Math.min(100, porcentaje)) / 100);
  const cont = el("div", { class: "ring", style: `width:${tamano}px;height:${tamano}px` });
  cont.innerHTML = `
    <svg width="${tamano}" height="${tamano}" viewBox="0 0 ${tamano} ${tamano}" aria-hidden="true">
      <circle cx="${tamano / 2}" cy="${tamano / 2}" r="${radio}" fill="none" stroke="var(--bg-sunken)" stroke-width="7"/>
      <circle cx="${tamano / 2}" cy="${tamano / 2}" r="${radio}" fill="none" stroke="var(--accent)" stroke-width="7"
        stroke-dasharray="${circ.toFixed(1)}" stroke-dashoffset="${offset.toFixed(1)}" stroke-linecap="round"/>
    </svg>
    <div class="ring-label">${etiqueta ?? porcentaje + "%"}</div>`;
  return cont;
}

/* Formato de fechas en español, tolerante a nulos */
export function fecha(iso, conHora = false) {
  if (!iso) return "—";
  const d = new Date(iso);
  if (isNaN(d)) return "—";
  const opciones = conHora
    ? { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" }
    : { day: "2-digit", month: "short", year: "numeric" };
  return d.toLocaleDateString("es-ES", opciones);
}
export function haceCuanto(iso) {
  if (!iso) return "nunca";
  const min = Math.round((Date.now() - new Date(iso)) / 60000);
  if (isNaN(min)) return "nunca";
  if (min < 1) return "ahora mismo";
  if (min < 60) return `hace ${min} min`;
  const h = Math.round(min / 60);
  if (h < 24) return `hace ${h} h`;
  const d = Math.round(h / 24);
  if (d < 30) return `hace ${d} d`;
  return fecha(iso);
}

/* Registro del service worker (PWA) */
export function registrarPWA() {
  if (!("serviceWorker" in navigator)) return;
  if (location.protocol === "file:") return; // no funciona abriendo el archivo directamente
  const r = raiz();
  navigator.serviceWorker.register(r + "sw.js").catch(() => {});
}

/* Arranque estándar de una página */
export async function arrancar(pagina) {
  await store.init();
  montarCabecera(pagina);
  registrarPWA();
  // Señal para el diagnóstico de arranque incrustado en cada página:
  // si esto no llega a ejecutarse, la página muestra un aviso explicando qué falta.
  window.__appLista = true;
  return store;
}
