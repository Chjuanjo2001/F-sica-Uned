/* ==========================================================================
   BANCO DE PREGUNTAS — Análisis Matemático I · Tema 1: Preliminares
   Fuente: Capítulo P del libro de la asignatura (UNED).
   Cada pregunta lleva un id estable: no cambiarlo nunca, porque el progreso
   y la cola de repaso espaciado se guardan usando ese id.
   ========================================================================== */

export const ESTACIONES = [
  {
    id: "s1",
    titulo: "La recta real",
    preguntas: [
      {
        id: "s1q1",
        q: "Un sensor marca T = 20 °C con una tolerancia de ±0,5 °C. ¿Qué desigualdad describe la temperatura real x?",
        opts: ["|x − 20| &lt; 0,5", "|x − 0,5| &lt; 20", "|x| &lt; 20,5", "x &lt; 0,5"],
        correcta: 0,
        explica: "La tolerancia de un instrumento define una vecindad: la distancia entre el valor real y la lectura tiene que ser menor que el margen de error.",
      },
      {
        id: "s1q2",
        q: "¿Cuál es el conjunto solución de |x − 3| ≤ 2?",
        opts: ["[1, 5]", "(1, 5)", "[−1, 5]", "[5, ∞)"],
        correcta: 0,
        explica: "|x − a| ≤ D equivale a a − D ≤ x ≤ a + D. Aquí 3 − 2 = 1 y 3 + 2 = 5, con los extremos incluidos por el ≤.",
      },
      {
        id: "s1q3",
        q: "√2 es irracional. ¿Qué significa eso físicamente para una medida?",
        opts: [
          "Que no puede escribirse como cociente exacto de enteros, aunque ocupa un punto perfectamente definido de la recta real",
          "Que no existe en la recta real",
          "Que solo tiene sentido en geometría, no en cálculo",
        ],
        correcta: 0,
        explica: "La completitud de ℝ garantiza que no hay huecos: √2 ocupa un punto exacto. Que su desarrollo decimal no termine no le quita realidad física.",
      },
    ],
  },
  {
    id: "s2",
    titulo: "Plano, incrementos y rectas",
    preguntas: [
      {
        id: "s2q1",
        q: "Una partícula pasa de x₁ = 2 m en t₁ = 1 s a x₂ = 10 m en t₂ = 3 s. ¿Cuál es su velocidad media?",
        opts: ["4 m/s", "8 m/s", "2 m/s", "5 m/s"],
        correcta: 0,
        explica: "v̄ = Δx/Δt = (10 − 2)/(3 − 1) = 8/2 = 4 m/s. La velocidad media es exactamente la pendiente de la recta que une los dos puntos en la gráfica x(t).",
      },
      {
        id: "s2q2",
        q: "En una gráfica posición–tiempo, ¿qué significaría un tramo perfectamente vertical?",
        opts: [
          "Velocidad infinita: imposible para un objeto con masa",
          "Reposo total",
          "Velocidad constante",
        ],
        correcta: 0,
        explica: "Un tramo vertical tiene Δt = 0, y la pendiente Δx/0 queda indefinida. Es la misma razón por la que la pendiente de una recta vertical no existe.",
      },
      {
        id: "s2q3",
        q: "Dos rectas en una gráfica x(t) tienen la misma pendiente. ¿Qué comparten los dos movimientos?",
        opts: [
          "La misma velocidad, aunque partan de posiciones distintas",
          "La misma posición inicial",
          "El mismo instante de llegada",
        ],
        correcta: 0,
        explica: "Rectas paralelas ⇒ misma pendiente ⇒ misma velocidad. Lo que cambia es la ordenada en el origen, es decir, desde dónde salió cada objeto.",
      },
    ],
  },
  {
    id: "s3",
    titulo: "Cónicas",
    preguntas: [
      {
        id: "s3q1",
        q: "¿Por qué la trayectoria de un proyectil sin rozamiento es una parábola?",
        opts: [
          "Porque al eliminar t entre x(t) y y(t) aparece un término en x², cuadrático",
          "Porque la velocidad es constante",
          "Porque la Tierra es curva",
        ],
        correcta: 0,
        explica: "x(t) = v₀cosθ·t es lineal en t. Despejando t = x/(v₀cosθ) y sustituyendo en y(t) = v₀senθ·t − ½gt² sale y(x) con un término en x²: una parábola.",
      },
      {
        id: "s3q2",
        q: "Según la 1ª ley de Kepler, ¿dónde está el Sol en la órbita elíptica de un planeta?",
        opts: ["En uno de los dos focos", "En el centro geométrico", "Fuera de la elipse"],
        correcta: 0,
        explica: "El Sol ocupa un foco, no el centro. Por eso la distancia Tierra–Sol cambia a lo largo del año (perihelio y afelio).",
      },
      {
        id: "s3q3",
        q: "¿Qué propiedad de la parábola hace que se use en antenas y telescopios?",
        opts: [
          "Todos los rayos paralelos al eje se reflejan y convergen en el foco",
          "Todos sus puntos equidistan del centro",
          "No tiene curvatura",
        ],
        correcta: 0,
        explica: "Es la propiedad de reflexión: concentra en un único punto toda la señal paralela que recibe. De ahí la forma de los espejos primarios y las parabólicas.",
      },
    ],
  },
  {
    id: "s4",
    titulo: "Funciones, gráficas y simetría",
    preguntas: [
      {
        id: "s4q1",
        q: "Si f(x) = x², ¿qué le ocurre a la gráfica al pasar a g(x) = f(x − 3) + 1?",
        opts: [
          "Se desplaza 3 unidades a la derecha y 1 hacia arriba",
          "Se desplaza 3 a la izquierda y 1 hacia abajo",
          "Se invierte respecto al eje x",
        ],
        correcta: 0,
        explica: "Sustituir x por x − c desplaza c unidades a la derecha; sumar una constante al final desplaza hacia arriba.",
      },
      {
        id: "s4q2",
        q: "La función sen(x) cumple sen(−x) = −sen(x). Por tanto es…",
        opts: ["Impar", "Par", "Ni par ni impar"],
        correcta: 0,
        explica: "Es la definición de función impar, y se ve en el círculo unidad: al reflejar el ángulo respecto al eje x, la coordenada y cambia de signo.",
      },
      {
        id: "s4q3",
        q: "Un pozo de potencial cumple U(x) = U(−x): misma energía a ambos lados del origen. Matemáticamente U es…",
        opts: ["Una función par", "Una función impar", "Ni par ni impar"],
        correcta: 0,
        explica: "U(x) = U(−x) es literalmente la definición de función par. Esta simetría es la que después justifica que los estados propios tengan paridad definida en cuántica.",
      },
    ],
  },
  {
    id: "s5",
    titulo: "Composición de funciones",
    preguntas: [
      {
        id: "s5q1",
        q: "Si g convierte grados a radianes y f(x) = sen(x), ¿cuánto vale f(g(90))?",
        opts: ["sen(π/2) = 1", "sen(90) tomando 90 como radianes", "90 radianes"],
        correcta: 0,
        explica: "g(90) = 90·π/180 = π/2 rad, y después f aplica el seno: sen(π/2) = 1. Es el error de calculadora más común: trabajar en el modo angular equivocado.",
      },
      {
        id: "s5q2",
        q: "En la composición f∘g, ¿qué función actúa primero sobre x?",
        opts: ["g, la función interna", "f, la función externa", "Las dos a la vez"],
        correcta: 0,
        explica: "(f∘g)(x) = f(g(x)): x entra en g y su salida alimenta a f. Es una cadena de montaje, y el orden importa: f∘g ≠ g∘f en general.",
      },
      {
        id: "s5q3",
        q: "En caída libre, v(t) = g·t y Ec(v) = ½mv². Escribir Ec(t) = ½m(gt)² es un ejemplo de…",
        opts: [
          "Composición de funciones: la energía depende de v, que depende de t",
          "Una simple multiplicación",
          "Una función inversa",
        ],
        correcta: 0,
        explica: "Encadenar magnitudes físicas que dependen unas de otras es composición pura. Más adelante, derivar esa cadena será la regla de la cadena.",
      },
    ],
  },
  {
    id: "s6",
    titulo: "Polinomios y raíces",
    preguntas: [
      {
        id: "s6q1",
        q: "En h(t) = At² + Bt + C, si el discriminante Δ = B² − 4AC es negativo, ¿qué ocurre?",
        opts: [
          "No hay ningún instante real en que la altura sea cero: la parábola no corta el eje t",
          "El proyectil vuela para siempre",
          "Hay dos instantes de impacto",
        ],
        correcta: 0,
        explica: "Sin raíces reales la gráfica no toca el eje horizontal. Físicamente significa que, con esos coeficientes, el modelo nunca alcanza esa altura.",
      },
      {
        id: "s6q2",
        q: "Se lanza un objeto con h(t) = −4,9t² + 20t. ¿Qué representa la raíz positiva de h(t) = 0?",
        opts: [
          "El instante en que vuelve al nivel de partida",
          "La altura máxima alcanzada",
          "La velocidad de lanzamiento",
        ],
        correcta: 0,
        explica: "Las raíces son los instantes de altura cero: t = 0 es el lanzamiento y la otra raíz, t ≈ 4,08 s, el aterrizaje.",
      },
      {
        id: "s6q3",
        q: "¿Qué representa el coeficiente A = −4,9 en h(t) = At² + Bt + C?",
        opts: [
          "La mitad de la gravedad, negativa porque apunta hacia abajo",
          "La velocidad inicial",
          "La altura inicial",
        ],
        correcta: 0,
        explica: "h(t) = −½gt² + v₀t + h₀ y ½·9,8 = 4,9. El signo recoge que la aceleración va en sentido contrario al eje de alturas.",
      },
    ],
  },
  {
    id: "s7",
    titulo: "Trigonometría y el círculo",
    preguntas: [
      {
        id: "s7q1",
        q: "En el círculo unidad, el punto correspondiente al ángulo θ tiene coordenadas…",
        opts: ["(cos θ, sen θ)", "(sen θ, cos θ)", "(θ, θ)"],
        correcta: 0,
        explica: "Es la definición moderna de seno y coseno: las proyecciones del punto sobre los ejes x e y. De ahí sale gratis cos²θ + sen²θ = 1.",
      },
      {
        id: "s7q2",
        q: "Un muelle oscila según x(t) = A·cos(ωt). Geométricamente, ese movimiento es…",
        opts: [
          "La proyección sobre un eje de un punto que gira uniformemente en un círculo de radio A",
          "Una recta de pendiente A",
          "Una parábola de altura A",
        ],
        correcta: 0,
        explica: "El movimiento armónico simple es la sombra de un movimiento circular uniforme. Por eso toda la trigonometría reaparece en ondas y oscilaciones.",
      },
      {
        id: "s7q3",
        q: "Según la regla CPST, ¿en qué cuadrante son negativos a la vez el seno y el coseno?",
        opts: ["Tercer cuadrante", "Primer cuadrante", "Segundo cuadrante"],
        correcta: 0,
        explica: "En el tercer cuadrante solo la tangente es positiva, al ser cociente de dos cantidades negativas.",
      },
    ],
  },
];

export const EXAMEN = [
  {
    id: "ex1",
    q: "Una resistencia mide R = 100 Ω con tolerancia del 2 %. ¿Qué desigualdad la describe?",
    opts: ["|R − 100| &lt; 2", "|R| &lt; 100", "R = 2"],
    correcta: 0,
    explica: "El 2 % de 100 Ω son 2 Ω de margen alrededor del valor nominal.",
  },
  {
    id: "ex2",
    q: "En una gráfica x(t), la pendiente de la recta que une dos instantes representa…",
    opts: ["La velocidad media", "La posición inicial", "La aceleración instantánea"],
    correcta: 0,
    explica: "Δx/Δt es la definición de velocidad media, y es exactamente la pendiente.",
  },
  {
    id: "ex3",
    q: "¿Qué curva describe un balón lanzado al aire sin rozamiento?",
    opts: ["Una parábola", "Una elipse", "Una hipérbola"],
    correcta: 0,
    explica: "Aceleración constante hacia abajo ⇒ posición cuadrática en el tiempo ⇒ parábola.",
  },
  {
    id: "ex4",
    q: "La órbita de la Tierra es una elipse y el Sol está…",
    opts: ["En uno de sus focos", "En el centro", "En el eje menor"],
    correcta: 0,
    explica: "Primera ley de Kepler.",
  },
  {
    id: "ex5",
    q: "f(x) = x⁴ − 3x² + 1 es…",
    opts: ["Una función par", "Una función impar", "Ni par ni impar"],
    correcta: 0,
    explica: "Solo tiene potencias pares de x, luego f(−x) = f(x).",
  },
  {
    id: "ex6",
    q: "En f(g(x)), ¿qué se calcula primero?",
    opts: ["g(x)", "f(x)", "Da igual el orden"],
    correcta: 0,
    explica: "La función interna se evalúa primero y su salida entra en la externa.",
  },
  {
    id: "ex7",
    q: "Si el discriminante de la ecuación de altura es negativo, el modelo dice que el objeto…",
    opts: [
      "No alcanza esa altura en ningún instante real",
      "Cae inmediatamente",
      "Vuela indefinidamente",
    ],
    correcta: 0,
    explica: "Sin raíces reales, la parábola no corta el eje de tiempos.",
  },
  {
    id: "ex8",
    q: "x(t) = A·cos(ωt) es la proyección de un punto que…",
    opts: ["Gira uniformemente sobre un círculo", "Se mueve en línea recta", "Cae libremente"],
    correcta: 0,
    explica: "Movimiento circular uniforme proyectado = movimiento armónico simple.",
  },
];

/* Todas las preguntas del tema, indexadas por id (lo usa el repaso espaciado) */
export const TODAS = [...ESTACIONES.flatMap((e) => e.preguntas), ...EXAMEN];
export const META = {
  subject: "am1",
  topic: "preliminares",
  titulo: "Preliminares",
  ruta: "temas/am1-01-preliminares.html",
};
